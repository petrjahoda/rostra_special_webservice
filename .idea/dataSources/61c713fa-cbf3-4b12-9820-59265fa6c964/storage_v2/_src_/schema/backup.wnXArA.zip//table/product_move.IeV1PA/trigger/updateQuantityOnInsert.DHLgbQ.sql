create definer = root@localhost trigger updateQuantityOnInsert
    after insert
    on product_move
    for each row
begin
  if NEW.type='In' then
    update product set quantity=quantity+abs(NEW.quantity) where id=NEW.product_id;
  else
    update product set quantity=quantity-abs(NEW.quantity) where id=NEW.product_id;
  end if;
end;

